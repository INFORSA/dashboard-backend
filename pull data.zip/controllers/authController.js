const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const db = require('../config/db');

exports.login = (req, res) => {
  const { username, password } = req.body;

  const sqlSelect = `
    SELECT user.*, role.nama_role 
    FROM user 
    JOIN role ON user.role = role.id_role 
    WHERE user.username = ?
  `;

  db.query(sqlSelect, [username], async (err, result) => {
    if (err) {
      console.error('Server error:', err);
      return res.status(500).send('Server error');
    }

    if (result.length === 0) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    const user = result[0];
    const match = await bcrypt.compare(password, user.password);

    if (!match) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    const role = user.nama_role;

    // Default token payload
    let tokenPayload = {
      username: user.username,
      role,
    };

    // Jika role-nya "user", tambahkan nim dari tabel anggota
    if (role === 'staff') {
      const sqlNim = `
        SELECT nim 
        FROM anggota 
        WHERE nama_staff = ?
        LIMIT 1
      `;

      db.query(sqlNim, [username], (err, resultNim) => {
        if (err) {
          console.error('Error getting NIM:', err);
          return res.status(500).send('Server error');
        }

        const nim = resultNim[0]?.nim;
        if (nim) tokenPayload.nim = nim;

        // Buat dan kirim token
        const token = jwt.sign(tokenPayload, 'INFORSA', { expiresIn: '1h' });

        res.cookie('token', token, {
          httpOnly: true,
          secure: true, // sesuaikan dengan env
          sameSite: 'None',
          maxAge: 60 * 60 * 1000,
        });

        return res.json({ message: 'Login sukses' });
      });
    } else {
      // Untuk role superadmin atau admin
      const token = jwt.sign(tokenPayload, 'INFORSA', { expiresIn: '1h' });

      res.cookie('token', token, {
        httpOnly: true,
        secure: true,
        sameSite: 'None',
        maxAge: 60 * 60 * 1000,
      });

      return res.json({ message: 'Login sukses' });
    }
  });
};

exports.logout = (req, res) => {
  res.clearCookie('token', {
    httpOnly: true,
    secure: true,   
    sameSite: 'none',
  });
  res.json({ message: 'Logout berhasil' });
};

exports.me = (req, res) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ message: "Tidak ada token" });

  jwt.verify(token, "INFORSA", async(err, decoded) => {
    if (err) return res.status(403).json({ message: "Token tidak valid" });
    const { username, role } = decoded;

    if(role === "admin"){
      const sql = `
        SELECT departemen.nama AS nama_departemen, pengurus.keterangan AS keterangan
        FROM user 
        LEFT JOIN pengurus ON user.id_user = pengurus.user_id
        LEFT JOIN departemen ON pengurus.dept_id = departemen.id_depart
        WHERE user.username = ?
        LIMIT 1
      `;

      db.query(sql, [username], (err, results) => {
        if (err) return res.status(500).json({ message: "Gagal mengambil data departemen" });

        const departemen = results[0]?.nama_departemen || null;
        const keterangan = results[0]?.keterangan || null;
        return res.json({ username, role, departemen, keterangan });
      });
    }else{
      res.json({ username, role });
    }
  });
};

exports.registerAdmin = async (req, res) => {
    const { username, password, role, jabatan, dept_id, keterangan } = req.body;
  
    try {
      // Cek apakah user sudah ada
      const sqlCheck = "SELECT * FROM user WHERE username = ?";
      db.query(sqlCheck, [username], async (err, result) => {
        if (err) {
          console.error("DB Error:", err); // Menampilkan error DB ke console
          return res.status(500).json({ message: "Gagal memeriksa user" });
        }
  
        if (result.length > 0) {
          return res.status(400).json({ message: "Username sudah terdaftar" });
        }
  
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        var roleChoosen = 1;
        if (role === "BPI" || role === "MPKO"){
          roleChoosen = 1;
        }else if(role === "BPH"){
          roleChoosen = 2;
        }else{
          roleChoosen = 4
        }
        const sqlInsert = "INSERT INTO user (username, password, role) VALUES (?, ?, ?)";
        db.query(sqlInsert, [username, hashedPassword, roleChoosen], (err, result) => {
          if (err) {
            console.error("DB Error:", err); // Menampilkan error DB ke console
            return res.status(500).json({ message: "Gagal menyimpan user" });
          }
          
          // Ambil ID user yang baru dibuat
          const userId = result.insertId;

          // Jika role BPH, insert juga ke tabel pengurus
          if (roleChoosen === 2) {
            const sqlInsertPengurus = `
              INSERT INTO pengurus (user_id, dept_id, jabatan, keterangan)
              VALUES (?, ?, ?, ?)
            `;
            // Misal dept_id BPH = 1 (ubah sesuai kebutuhan)
            db.query(sqlInsertPengurus, [userId, dept_id, jabatan, keterangan || ""], (err) => {
              if (err) {
                console.error("DB Error:", err);
                return res.status(500).json({ message: "Gagal menyimpan data pengurus" });
              }

              return res.status(201).json({ message: "Registrasi berhasil & pengurus ditambahkan!" });
            });
          } else {
            return res.status(201).json({ message: "Registrasi berhasil!" });
          }
        });
      });
    } catch (error) {
      console.error("Error:", error); // Log error yang tidak terduga
      res.status(500).json({ message: "Terjadi kesalahan pada server" });
    }
  };  